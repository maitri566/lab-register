# L61 - Lab Attendance Register
**Student:** VAMJA MAITRI NILESHBHAI | **Roll:** H34 | **Division:** H | **Enrollment:** 24004501210467

## Problem
Build a lab attendance script that marks P/A for every student in a loop and finds defaulters.

## Folder Structure
- `main.sh`: Interactive menu-driven shell script.
- `lib/functions.sh`: Contains logic for Features 1-5, backups, logs, and cron tasks.
- `data/`: Holds `students.txt` (student roster) and `attendance.csv` (attendance records).
- `reports/`: Directory where generated attendance reports are saved.
- `backups/`: Stores daily and manual tar.gz/csv backups.
- `logs/`: Contains `activity.log` and `cron.log`.

## Data Columns
### students.txt
- `roll`: Unique student roll number (e.g., G01, G02).
- `name`: Full name of the student.

### attendance.csv
- `date`: Date of the session (YYYY-MM-DD).
- `roll`: Student roll number.
- `status`: Attendance status ('P' for Present, 'A' for Absent).

## How to Run
```bash
./main.sh
