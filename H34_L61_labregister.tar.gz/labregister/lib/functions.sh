#!/bin/bash
DATA="data/students.txt"
ATT_FILE="data/attendance.csv"
LOG="logs/activity.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') | $*" >> "$LOG"
}

check_data() {
    if [ ! -f "$DATA" ]; then
        echo "Student file not found: $DATA"
        return 1
    fi
    if [ ! -f "$ATT_FILE" ]; then
        touch "$ATT_FILE"
    fi
}

show_help() {
    echo "Usage: ./main.sh          -> open the menu"
    echo "       ./main.sh --help   -> show this help"
    echo "       ./main.sh --backup -> backup data/ now"
    echo "       ./main.sh --cron   -> run the scheduled (crontab) task"
}

view_data() {
    check_data || return
    echo "=== Students Data ($DATA) ==="
    cat -n "$DATA"
    echo ""
    echo "=== Attendance Records ($ATT_FILE) ==="
    if [ -s "$ATT_FILE" ]; then
        cat "$ATT_FILE"
    else
        echo "No attendance entries recorded yet."
    fi
}

do_backup() {
    f="backups/data_$(date +%Y%m%d_%H%M%S).tar.gz"
    tar -czf "$f" data/
    echo "Backup saved: $f ($(du -h "$f" | cut -f1))"
    log "backup created $f"
}

view_log() {
    if [ -f "$LOG" ]; then
        tail -n 15 "$LOG"
    else
        echo "No activity yet."
    fi
}

cron_task() {
    local target="backups/attendance_$(date +%Y-%m-%d).csv"
    if [ -f "$ATT_FILE" ]; then
        cp "$ATT_FILE" "$target"
        echo "$(date '+%Y-%m-%d %H:%M') | Copied $ATT_FILE to $target" >> reports/cron_output.txt
    fi
    log "cron task ran"
}

feature_1() {
    check_data || return
    local today
    today=$(date +%Y-%m-%d)
    echo "== Mark today's attendance for all students in a while-read loop =="
    echo "Date: $today"

    while IFS=',' read -r roll name; do
        roll=$(echo "$roll" | xargs)
        name=$(echo "$name" | xargs)
        if [ "$roll" = "roll" ] || [ -z "$roll" ]; then continue; fi

        while true; do
            read -p "Roll $roll ($name) [P/A]: " status < /dev/tty
            status=$(echo "$status" | tr '[:lower:]' '[:upper:]')
            case "$status" in
                P|A)
                    echo "$today,$roll,$status" >> "$ATT_FILE"
                    break
                    ;;
                *)
                    echo "Invalid input. Please enter P or A."
                    ;;
            esac
        done
    done < "$DATA"

    echo "Attendance marked successfully for $today."
    log "feature_1 used: marked for $today"
}

feature_2() {
    check_data || return
    echo "== Show attendance % of one student =="
    read -p "Enter roll number (e.g., G01): " key < /dev/tty
    key=$(echo "$key" | tr '[:lower:]' '[:upper:]' | xargs)

    if ! grep -q "^$key," "$DATA"; then
        echo "Student roll '$key' not found in $DATA."
        return
    fi

    local student_name
    student_name=$(grep "^$key," "$DATA" | cut -d',' -f2 | xargs)

    local total present pct
    total=$(grep -c ",$key," "$ATT_FILE" 2>/dev/null || echo 0)
    present=$(grep ",$key,P" "$ATT_FILE" 2>/dev/null | wc -l)

    if [ "$total" -eq 0 ]; then
        echo "No attendance recorded yet for $student_name ($key)."
        return
    fi

    pct=$(awk -v p="$present" -v t="$total" 'BEGIN { printf "%.2f", (p / t) * 100 }')
    echo "----------------------------------------"
    echo "Student: $student_name ($key)"
    echo "Present: $present / Total: $total"
    echo "Attendance: $pct%"
    echo "----------------------------------------"
    log "feature_2 used for $key ($pct%)"
}

feature_3() {
    check_data || return
    echo "== List defaulters below 75% =="
    printf "%-8s %-22s %-12s %-8s\n" "ROLL" "NAME" "ATTENDANCE" "PERCENT"
    echo "---------------------------------------------------------"

    local found=0
    while IFS=',' read -r roll name; do
        roll=$(echo "$roll" | xargs)
        name=$(echo "$name" | xargs)
        if [ "$roll" = "roll" ] || [ -z "$roll" ]; then continue; fi

        local total present
        total=$(grep -c ",$roll," "$ATT_FILE" 2>/dev/null || echo 0)
        present=$(grep ",$roll,P" "$ATT_FILE" 2>/dev/null | wc -l)

        if [ "$total" -gt 0 ]; then
            local pct
            pct=$(awk -v p="$present" -v t="$total" 'BEGIN { printf "%.2f", (p / t) * 100 }')
            if awk -v val="$pct" 'BEGIN { exit !(val < 75.0) }'; then
                printf "%-8s %-22s %-12s %-8s\n" "$roll" "$name" "$present/$total" "$pct%"
                found=1
            fi
        fi
    done < "$DATA"

    if [ "$found" -eq 0 ]; then
        echo "No defaulters found below 75%."
    fi
    log "feature_3 used"
}

feature_4() {
    check_data || return
    echo "== Total present count per date =="
    if [ ! -s "$ATT_FILE" ]; then
        echo "No attendance data available in $ATT_FILE."
        return
    fi

    printf "%-14s %-14s\n" "DATE" "PRESENT COUNT"
    echo "----------------------------"
    awk -F',' '$3=="P" { count[$1]++ } END { for (d in count) printf "%-14s %-14d\n", d, count[d] }' "$ATT_FILE" | sort
    log "feature_4 used"
}

feature_5() {
    check_data || return
    echo "== Export a monthly report to reports/ =="
    local out="reports/report_$(date +%Y-%m-%d).txt"
    {
        echo "===== Lab Attendance Register Report $(date) ====="
        echo ""
        echo "-- Present Count Per Date --"
        awk -F',' '$3=="P" { count[$1]++ } END { for (d in count) printf "Date: %s | Present: %d\n", d, count[d] }' "$ATT_FILE" | sort
        echo ""
        echo "-- Defaulters (< 75%) --"
        while IFS=',' read -r roll name; do
            roll=$(echo "$roll" | xargs)
            name=$(echo "$name" | xargs)
            if [ "$roll" = "roll" ] || [ -z "$roll" ]; then continue; fi
            total=$(grep -c ",$roll," "$ATT_FILE" 2>/dev/null || echo 0)
            present=$(grep ",$roll,P" "$ATT_FILE" 2>/dev/null | wc -l)
            if [ "$total" -gt 0 ]; then
                pct=$(awk -v p="$present" -v t="$total" 'BEGIN { printf "%.2f", (p / t) * 100 }')
                if awk -v val="$pct" 'BEGIN { exit !(val < 75.0) }'; then
                    printf "Roll: %s | %s | Attended: %d/%d (%s%%)\n" "$roll" "$name" "$present" "$total" "$pct"
                fi
            fi
        done < "$DATA"
    } > "$out"

    echo "Report saved to $out"
    echo ""
    cat "$out"
    log "feature_5 used: saved to $out"
}
