#!/bin/bash
# main.sh L61 Lab Attendance Register
cd "$(dirname "$0")" || exit 1
source lib/functions.sh

case "$1" in
  --help) show_help; exit 0;;
  --backup) do_backup; exit 0;;
  --cron) cron_task; exit 0;;
esac

while true; do
  echo ""
  echo "========== LAB ATTENDANCE REGISTER =========="
  echo "1) Mark today's attendance for all students in a while-read loop"
  echo "2) Show attendance % of one student"
  echo "3) List defaulters below 75%"
  echo "4) Show the total present count per date"
  echo "5) Export a monthly report to reports/"
  echo "6) View data"
  echo "7) Backup data (tar.gz)"
  echo "8) View activity log"
  echo "0) Exit"
  read -p "Choose an option: " ch
  case "$ch" in
    1) feature_1;;
    2) feature_2;;
    3) feature_3;;
    4) feature_4;;
    5) feature_5;;
    6) view_data;;
    7) do_backup;;
    8) view_log;;
    0) echo "Bye!"; break;;
    *) echo "Invalid choice, try again.";;
  esac
done
